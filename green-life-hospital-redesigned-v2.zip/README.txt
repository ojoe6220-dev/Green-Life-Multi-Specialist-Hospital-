UPLOAD TO GITHUB
1. Upload index.html, style.css and script.js to your repository.
2. Commit the changes.
3. GitHub Pages should automatically rebuild the site.
4. Keep the three files in the repository root.

Verified facility details used:
Phone: 0703 474 1111
Email: greenlifehosp@gmail.com
Address: Behind Iroyin Ayo Baptist Church, Kima Area, Ogbomoso, Oyo State, Nigeria.
Coordinates: 8.12765, 4.25920
